<?php

// Note, this will be updated automatically during grunt release task3.0.94
$ET_CORE_VERSION = '3.0.94';
